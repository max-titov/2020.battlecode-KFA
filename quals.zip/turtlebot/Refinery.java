package turtlebot;
import battlecode.common.*;

public class Refinery extends Building {
    public Refinery(RobotController r) throws GameActionException {
        super(r);
    }
}
