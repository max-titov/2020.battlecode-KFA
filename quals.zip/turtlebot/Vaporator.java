package turtlebot;
import battlecode.common.*;

public class Vaporator extends Building {
    public Vaporator(RobotController r) throws GameActionException {
        super(r);
    }
}
