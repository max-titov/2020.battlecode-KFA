package turtlebot;
import battlecode.common.*;

public class Unit extends Robot {


    public Unit(RobotController r) throws GameActionException {
        super(r);
    }

    public void takeTurn() throws GameActionException {
        super.takeTurn();  
    }
}