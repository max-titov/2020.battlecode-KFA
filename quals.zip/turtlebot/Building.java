package turtlebot;
import battlecode.common.*;

public class Building extends Robot {

    public Building(RobotController r) throws GameActionException {
        super(r);
        // building specific setup here
    }

    public void takeTurn() throws GameActionException {
        super.takeTurn();
    }
}